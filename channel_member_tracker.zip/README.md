# Silent Telegram Channel Member Tracker

This bot records member join/leave status without posting join/leave messages in the channel.

## Setup

1. Create the bot with BotFather.
2. Add the bot to your channel as an administrator.
3. Give it the required admin access so it can receive member updates.
4. Set the `BOT_TOKEN` environment variable.
5. Install dependencies:

```bash
pip install -r requirements.txt
```

6. Run:

```bash
python bot.py
```

## Commands

- `/start` — check that the bot is running
- `/stats` — show recorded statistics

The database is stored in `members.db`.

## Important

The bot uses Telegram's `chat_member` updates. It does not send automatic join/leave messages to the channel.
