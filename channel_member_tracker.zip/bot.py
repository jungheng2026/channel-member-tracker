import os
import sqlite3
from datetime import datetime, timezone

from telegram import Update
from telegram.ext import Application, ChatMemberHandler, CommandHandler, ContextTypes

TOKEN = os.getenv("BOT_TOKEN")
DB_PATH = os.getenv("DB_PATH", "members.db")

if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is required")

db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.execute("""
CREATE TABLE IF NOT EXISTS members (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    joined_at TEXT,
    left_at TEXT,
    status TEXT NOT NULL
)
""")
db.commit()

def now():
    return datetime.now(timezone.utc).isoformat()

def save_member(user, status):
    cur = db.cursor()
    cur.execute("""
    INSERT INTO members (user_id, username, first_name, joined_at, left_at, status)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET
      username=excluded.username,
      first_name=excluded.first_name,
      left_at=excluded.left_at,
      status=excluded.status
    """, (
        user.id,
        user.username,
        user.first_name,
        now() if status == "member" else None,
        now() if status in ("left", "kicked") else None,
        status
    ))
    db.commit()

def is_joined(status):
    return status in ("member", "administrator", "creator", "restricted")

async def member_changed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cm = update.chat_member
    if not cm:
        return

    old = cm.old_chat_member.status
    new = cm.new_chat_member.status
    user = cm.new_chat_member.user

    old_in = is_joined(old)
    new_in = is_joined(new)

    if not old_in and new_in:
        save_member(user, "member")
    elif old_in and not new_in:
        save_member(user, new)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Silent tracker: only replies when an authorized user explicitly asks.
    total = db.execute(
        "SELECT COUNT(*) FROM members WHERE status IN ('member','administrator','creator','restricted')"
    ).fetchone()[0]
    joined = db.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    left = db.execute(
        "SELECT COUNT(*) FROM members WHERE status IN ('left','kicked')"
    ).fetchone()[0]
    await update.message.reply_text(
        f"📊 Tracker Stats\n\n"
        f"👥 Currently tracked: {total}\n"
        f"📥 Recorded joins: {joined}\n"
        f"📤 Recorded leaves: {left}"
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "✅ Channel Member Tracker is running.\n"
        "Join/leave events are recorded silently."
    )

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(ChatMemberHandler(member_changed, ChatMemberHandler.CHAT_MEMBER))
    app.run_polling(allowed_updates=["chat_member", "message"])

if __name__ == "__main__":
    main()
